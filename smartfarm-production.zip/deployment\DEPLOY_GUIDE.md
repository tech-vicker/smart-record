# 🚀 Quick Deploy SmartFarm Online - Step by Step

## 📋 **Easiest Method: InfinityFree (5 Minutes)**

### Step 1: Sign Up for Free Hosting
1. Go to **https://infinityfree.net**
2. Click **"Sign Up"**
3. Choose **Free Plan**
4. Enter your email and create password
5. Verify your email

### Step 2: Create Your Website
1. After login, click **"Create New Website"**
2. Choose a **subdomain** (e.g., yourfarm.infinityfree.net)
3. Select **"Upload Website"** option
4. Click **"Create Website"**

### Step 3: Prepare SmartFarm Files
1. On your computer, run the deployment script:
   ```cmd
   deploy.bat
   ```
2. Choose **Option 3** (Shared Hosting Preparation)
3. This creates a **deployment** folder with all necessary files

### Step 4: Upload Files
1. In InfinityFree control panel, click **"File Manager"**
2. Go to **public_html** folder
3. Delete all existing files
4. Click **"Upload"**
5. Upload the entire **deployment** folder contents
6. Or upload the **deployment.zip** (if created)

### Step 5: Set Permissions
1. In File Manager, select all folders
2. Right-click → **"Permissions"**
3. Set to **755** (Read, Write, Execute for owner; Read, Execute for others)
4. Select all PHP files
5. Set permissions to **644** (Read, Write for owner; Read for others)

### Step 6: Configure Database
1. In File Manager, create a **db** folder
2. Set **db** folder permissions to **755**
3. Create an empty file **database.sqlite** inside db folder
4. Set database file permissions to **644**

### Step 7: Test Your Site
1. Visit your subdomain: **yourfarm.infinityfree.net**
2. You should see the SmartFarm landing page
3. Click **"Get Started"** to register
4. Test all features work properly

## 🎯 **Alternative: 000Webhost (10 Minutes)**

### Step 1: Sign Up
1. Go to **https://www.000webhost.com**
2. Click **"Sign Up"**
3. Choose **Free Website** plan
4. Register with email

### Step 2: Upload Files
1. Access **File Manager** in control panel
2. Upload all files from **deployment** folder
3. Ensure **db** folder exists with proper permissions

## 🔧 **If You Have Your Own Domain**

### Option 1: Connect Domain to Free Hosting
1. In hosting control panel, find **"Domains"**
2. Click **"Add Domain"**
3. Enter your domain name
4. Update DNS settings as provided

### Option 2: Cheap Paid Hosting ($3-5/month)
1. **Hostinger** - $2.99/month
2. **Bluehost** - $3.95/month  
3. **SiteGround** - $3.99/month

## 🚨 **Troubleshooting Common Issues**

### "500 Internal Server Error"
- Check file permissions (755 for folders, 644 for files)
- Ensure database.sqlite exists in db folder
- Check PHP version (requires 7.4+)

### "Database Connection Failed"
- Create db folder if missing
- Create empty database.sqlite file
- Set proper permissions

### "White Screen/Blank Page"
- Enable PHP error display temporarily
- Check for syntax errors in PHP files
- Ensure all required files are uploaded

## 📱 **Mobile App Integration**

After deployment, you can:
1. Add to home screen on mobile
2. Enable offline mode
3. Send push notifications

## 🔒 **Security Tips**

1. Change default passwords
2. Enable SSL (free on most hosts)
3. Regular backups
4. Monitor for updates

## 🎉 **Success!**

Your SmartFarm is now live online! 🌾

**Share your URL with farmers and start managing agricultural operations professionally!**

---

**Need Help?** 
- Check the troubleshooting section
- Contact hosting support
- Review the README.md file
